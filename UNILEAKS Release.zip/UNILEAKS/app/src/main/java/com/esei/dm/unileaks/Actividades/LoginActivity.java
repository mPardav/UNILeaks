package com.esei.dm.unileaks.Actividades;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.esei.dm.unileaks.BasesDeDatos.DatabaseHelper;
import com.esei.dm.unileaks.R;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private DatabaseHelper databaseHelper;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;

    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Inicializar SharedPreferences
        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);

        // Configurar el modo oscuro según las preferencias
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar elementos de la interfaz de usuario (UI)
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);

        // Inicializar el ayudante de la base de datos
        databaseHelper = new DatabaseHelper(this);

        // Comprobar y agregar el usuario "admin" si no existe
        if (!databaseHelper.checkUsername("admin")) {
            databaseHelper.addUser("admin", "esei");
            databaseHelper.setAdmin(databaseHelper.getUserIdFromUsername("admin"), true);
        }

        // Configurar el escuchador de clics para el botón de inicio de sesión
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (databaseHelper.checkUser(username, password)) {
                    int userId = databaseHelper.getUserIdFromUsername(username);

                    // Guardar el nombre de usuario y su ID en SharedPreferences
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("username", username);
                    editor.putInt("userId", userId);
                    editor.apply();

                    // Iniciar la actividad de bienvenida
                    Intent intent = new Intent(LoginActivity.this, WelcomeActivity.class);
                    intent.putExtra("username", username);
                    startActivity(intent);
                    showToast("Inicio de sesión exitoso");
                } else {
                    showToast("Inicio de sesión fallido. Verifica tus credenciales.");
                }
            }
        });

        // Configurar el escuchador de clics para el botón de registro
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Iniciar la actividad de registro
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Configurar el modo oscuro según las preferencias al reanudar la actividad
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
