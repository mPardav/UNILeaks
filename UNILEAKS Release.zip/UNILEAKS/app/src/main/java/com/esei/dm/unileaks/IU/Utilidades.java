package com.esei.dm.unileaks.IU;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.MenuItem;
import android.net.Uri;

import com.esei.dm.unileaks.Actividades.ChatActivity;
import com.esei.dm.unileaks.Actividades.ForoActivity;
import com.esei.dm.unileaks.Actividades.LoginActivity;
import com.esei.dm.unileaks.Actividades.ProfileActivity;
import com.esei.dm.unileaks.Actividades.ResourcesActivity;
import com.esei.dm.unileaks.Actividades.WelcomeActivity;
import com.esei.dm.unileaks.R;

public class Utilidades {

    public static void compartirContenido(Context context, String mensaje) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT, mensaje);

        context.startActivity(Intent.createChooser(intent, "Compartir con:"));
    }

    public static void mostrarDialogoConfirmacion(Context context, String titulo, String mensaje) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(titulo);
        builder.setMessage(mensaje);

        builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Acción al hacer clic en "Sí"
                Intent intent = new Intent(context, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(intent);
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Acción al hacer clic en "Cancelar" o se cancela el diálogo
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    //Método para gestionar la navegación por el menú desplegable, gestiona los cambios de actividad
    public static boolean onNavigationItemSelected(Context context, MenuItem item) {
        int itemId = item.getItemId(); // Obtener el ID del elemento del menú seleccionado

        if (itemId == R.id.nav_home) {
            Intent intent = new Intent(context, WelcomeActivity.class);
            context.startActivity(intent);
        } else if (itemId == R.id.nav_forum) {
            Intent intent = new Intent(context, ForoActivity.class);
            context.startActivity(intent);
        } else if (itemId == R.id.nav_chat) {
            Intent chatIntent = new Intent(context, ChatActivity.class);
            context.startActivity(chatIntent);
        } else if (itemId == R.id.nav_resources) {
            Intent intent = new Intent(context, ResourcesActivity.class);
            context.startActivity(intent);
        } else if (itemId == R.id.nav_profile) {
            Intent intent = new Intent(context, ProfileActivity.class);
            context.startActivity(intent);
        } else if (itemId == R.id.nav_logout) {
            mostrarDialogoConfirmacion(
                    context,
                    "Confirmación de desconexión",
                    "¿Estás seguro de que quieres salir?"
            );
        } else if (itemId == R.id.nav_share) {
            compartirContenido(context, "https://www.unileaks.com");
        } else if (itemId == R.id.nav_rate) {
            String url = "https://github.com/mPardav/UNILeaks.git";
            // Crear un Intent para abrir el navegador web
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            // Iniciar la actividad del navegador web
            context.startActivity(intent);
        }
        return true;
    }
}
