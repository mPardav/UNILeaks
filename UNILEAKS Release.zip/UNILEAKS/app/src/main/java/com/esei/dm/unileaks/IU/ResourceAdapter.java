package com.esei.dm.unileaks.IU;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.esei.dm.unileaks.EstructurasDeDatos.Resource;
import com.esei.dm.unileaks.R;
import com.squareup.picasso.Picasso; // Asegúrate de tener Picasso añadido a tu proyecto

import java.util.ArrayList;

public class ResourceAdapter extends ArrayAdapter<Resource> {

    private Context context;
    private ArrayList<Resource> resourceList;

    public ResourceAdapter(Context context, ArrayList<Resource> resourceList) {
        super(context, 0, resourceList);
        this.context = context;
        this.resourceList = resourceList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(context).inflate(R.layout.list_item_resource, parent, false);
        }

        Resource currentResource = resourceList.get(position);

        ImageView imageView = listItem.findViewById(R.id.resourceImage);
        TextView nameTextView = listItem.findViewById(R.id.resourceName);
        TextView descriptionTextView = listItem.findViewById(R.id.resourceDescription);

        nameTextView.setText(currentResource.getName());
        descriptionTextView.setText(currentResource.getDescription());

        // Cargar la imagen utilizando Picasso (reemplaza "default_image" con tu imagen predeterminada)
        //Picasso.get().load(currentResource.getImageUrl()).placeholder(R.drawable.ic_rate_icon).into(imageView);
        Picasso.get().load(currentResource.getImageUrl()).into(imageView);
        return listItem;
    }
}
