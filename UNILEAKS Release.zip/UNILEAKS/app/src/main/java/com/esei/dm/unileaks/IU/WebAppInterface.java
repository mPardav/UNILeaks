package com.esei.dm.unileaks.IU;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import com.esei.dm.unileaks.BasesDeDatos.ForumDatabaseHelper;

import java.util.HashMap;
import java.util.Map;

public class WebAppInterface {
    private Context mContext;
    private String username;
    private Map<String, String> userColors;
    private SharedPreferences sharedPreferences;
    private ForumDatabaseHelper mDatabaseHelper;

    public WebAppInterface(Context context, String username) {
        mContext = context;
        this.username = username;
        userColors = new HashMap<>();
    }

    // Constructor que recibe el contexto y el helper de la base de datos
    public WebAppInterface(Context context, ForumDatabaseHelper databaseHelper) {
        mContext = context;
        mDatabaseHelper = databaseHelper;
        sharedPreferences = mContext.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
    }

    @JavascriptInterface
    @SuppressLint("Range")
    public String getRepliesForTopic(long topicId) {
        Cursor cursor = mDatabaseHelper.getRepliesForTopic(topicId);
        JSONArray jsonArray = new JSONArray();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                JSONObject jsonObject = new JSONObject();
                try {
                    int replyId = cursor.getInt(cursor.getColumnIndex("id"));
                    String replyContent = cursor.getString(cursor.getColumnIndex("content"));
                    String replyAuthor = cursor.getString(cursor.getColumnIndex("author"));

                    jsonObject.put("id", replyId);
                    jsonObject.put("content", replyContent);
                    jsonObject.put("author", replyAuthor);

                    jsonArray.put(jsonObject);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        return jsonArray.toString();
    }
    @JavascriptInterface
    public void createTopic(String title, String content, String author) {
        //Log.d("WebAppInterface", "Creating topic: " + title + ", " + content + " by " + author);
        // Agregar el tema a la base de datos usando el ForumDatabaseHelper
        long topicId = mDatabaseHelper.addTopic(title, content);
        //Log.d("WebAppInterface", "Topic created with ID: " + topicId);
    }

    @JavascriptInterface
    public void replyToTopic(long topicId, String content) {
        String author = sharedPreferences.getString("username", "");
        //Log.d("WebAppInterface", "Replying to topic: " + topicId + " with content: " + content + " by " + author);
        // Agregar la respuesta al tema en la base de datos usando el ForumDatabaseHelper
        mDatabaseHelper.addReply(topicId, content, author);
    }

    @JavascriptInterface
    public String getTopics() {
        //Log.d("WebAppInterface", "Retrieving topics from database");
        Cursor cursor = mDatabaseHelper.getAllTopics();
        return convertCursorToJson(cursor);
    }

    @JavascriptInterface
    public String getTopicDetails(long topicId) {
        Cursor cursor = mDatabaseHelper.getTopicById(topicId);
        JSONObject jsonObject = new JSONObject();

        if (cursor != null && cursor.moveToFirst()) {
            try {
                @SuppressLint("Range") int topicIdValue = cursor.getInt(cursor.getColumnIndex("id"));
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex("title"));
                @SuppressLint("Range") String content = cursor.getString(cursor.getColumnIndex("content"));
                @SuppressLint("Range") String author = cursor.getString(cursor.getColumnIndex("author"));

                jsonObject.put("id", topicIdValue);
                jsonObject.put("title", title);
                jsonObject.put("content", content);
                jsonObject.put("author", author);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        if (cursor != null) {
            cursor.close();
        }

        return jsonObject.toString();
    }

    // Método para convertir el cursor a formato JSON
    private String convertCursorToJson(Cursor cursor) {
        JSONArray jsonArray = new JSONArray();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                JSONObject jsonObject = new JSONObject();

                try {
                    @SuppressLint("Range") int topicId = cursor.getInt(cursor.getColumnIndex("id"));
                    @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex("title"));
                    @SuppressLint("Range") String content = cursor.getString(cursor.getColumnIndex("content"));
                    @SuppressLint("Range") String author = cursor.getString(cursor.getColumnIndex("author"));

                    jsonObject.put("id", topicId);
                    jsonObject.put("title", title);
                    jsonObject.put("content", content);
                    jsonObject.put("author", author);

                    jsonArray.put(jsonObject);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (cursor.moveToNext());
        }

        if (cursor != null) {
            cursor.close();
        }

        return jsonArray.toString();
    }

    @JavascriptInterface
    public String getUsernameFromAndroid() {
        //Log.d("WebAppInterface", "Getting username from SharedPreferences");
        username = sharedPreferences.getString("username", "");
        return username;
    }

    @JavascriptInterface
    public String getUserColor(String user) {
        // Obtener el color asociado al usuario
        if (userColors.containsKey(user)) {
            return userColors.get(user);
        } else {
            // Generar un color aleatorio si no está asignado
            String color = getRandomColor();
            userColors.put(user, color);
            return color;
        }
    }

    private String getRandomColor() {
        // Generar un color hexadecimal aleatorio
        String letters = "0123456789ABCDEF";
        StringBuilder color = new StringBuilder("#");
        for (int i = 0; i < 6; i++) {
            color.append(letters.charAt((int) Math.floor(Math.random() * 16)));
        }
        return color.toString();
    }

    @JavascriptInterface
    public String getChatMessages() {
        // Obtén una referencia a SharedPreferences
        SharedPreferences prefs = mContext.getSharedPreferences("chatPrefs", Context.MODE_PRIVATE);

        // Obtén los mensajes de chat existentes
        return prefs.getString("chatMessages", "");
    }

    @JavascriptInterface
    public void receiveChatMessage(String message) {
        // Obtén una referencia a SharedPreferences
        SharedPreferences prefs = mContext.getSharedPreferences("chatPrefs", Context.MODE_PRIVATE);
        // Obtén el editor de SharedPreferences
        SharedPreferences.Editor editor = prefs.edit();
        // Obtén los mensajes de chat existentes
        String existingMessages = prefs.getString("chatMessages", "");
        // Añade el nuevo mensaje a los mensajes existentes
        // Aquí estoy usando "\n" como delimitador entre mensajes
        String newMessages = existingMessages + "\n" + username + ": " + message;
        // Almacena los nuevos mensajes en SharedPreferences
        editor.putString("chatMessages", newMessages);
        // Aplica los cambios
        editor.apply();
    }
}
