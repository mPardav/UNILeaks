package com.esei.dm.unileaks.Actividades;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import com.esei.dm.unileaks.R;
import com.esei.dm.unileaks.IU.Utilidades;
import com.google.android.material.navigation.NavigationView;

public class ProfileActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    private SharedPreferences sharedPreferences;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Obtener las preferencias compartidas
        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);

        // Configurar el tema antes de setContentView
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        setContentView(R.layout.activity_profile);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        navigationView.bringToFront();

        // Configurar el toggle para el cajón de navegación
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_profile);

        // Obtener la referencia al interruptor de modo oscuro
        Switch darkModeSwitch = findViewById(R.id.darkModeSwitch);

        // Establecer el estado del interruptor según las preferencias
        darkModeSwitch.setChecked(sharedPreferences.getBoolean("DarkMode", false));

        // Establecer el listener para el interruptor de modo oscuro
        darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean("DarkMode", isChecked);
            editor.apply();

            // Configurar el tema para la actividad actual
            if (isChecked) {
                getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }

            // Reiniciar la actividad
            recreate();
        });

        // Obtener referencias a los elementos de la interfaz
        ImageView profileImage = findViewById(R.id.profileImage);
        Button changeNameButton = findViewById(R.id.changeNameButton);
        Button changePasswordButton = findViewById(R.id.changePasswordButton);
        TextView usuario = findViewById(R.id.usernameTextView);

        // Obtener el nombre de usuario de las preferencias compartidas y establecerlo en el TextView
        String username = sharedPreferences.getString("username", "");
        usuario.setText(username);

        // Configurar los eventos de clic para los botones
        changeNameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, CambioNombreActivity.class);
                startActivity(intent);
            }
        });

        changePasswordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, CambioPassActivity.class);
                startActivity(intent);
            }
        });
    }

    // Manejar el botón de retroceso para cerrar el cajón de navegación si está abierto
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Manejar los elementos del cajón de navegación
        return Utilidades.onNavigationItemSelected(this, item);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}
