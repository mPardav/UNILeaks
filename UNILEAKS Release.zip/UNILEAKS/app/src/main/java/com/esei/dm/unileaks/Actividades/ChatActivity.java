package com.esei.dm.unileaks.Actividades;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.esei.dm.unileaks.R;
import com.esei.dm.unileaks.IU.Utilidades;
import com.esei.dm.unileaks.IU.WebAppInterface;
import com.google.android.material.navigation.NavigationView;

public class ChatActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private WebView chatWebView;
    private DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    private String username;
    private SharedPreferences sharedPreferences;

    @SuppressLint({"MissingInflatedId", "SetJavaScriptEnabled"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);

        // Configuración del modo oscuro según las preferencias del usuario
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_chat);

        username = sharedPreferences.getString("username", "");

        // Configuración de la WebView
        chatWebView = findViewById(R.id.chatWebView);
        chatWebView.addJavascriptInterface(new WebAppInterface(this, username), "Android");

        WebSettings webSettings = chatWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        chatWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                chatWebView.loadUrl("javascript:onPageLoad()");
            }
        });

        // Concatenar el nombre de usuario a la URL eligiendo modo claro u oscuro desde las preferencias
        String url;
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            url = "file:///android_asset/Chat/ChatLocalDark.html?username=" + username;
        } else {
            url = "file:///android_asset/Chat/ChatLocal.html?username=" + username;
        }

        // Cargar el contenido HTML local desde la URL
        chatWebView.loadUrl(url);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Actualización del modo oscuro al reanudar la actividad
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return Utilidades.onNavigationItemSelected(this, item);
    }
}
