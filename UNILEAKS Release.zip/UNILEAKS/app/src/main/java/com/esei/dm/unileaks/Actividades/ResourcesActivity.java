package com.esei.dm.unileaks.Actividades;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.esei.dm.unileaks.R;
import com.esei.dm.unileaks.EstructurasDeDatos.Resource;
import com.esei.dm.unileaks.IU.ResourceAdapter;
import com.esei.dm.unileaks.IU.Utilidades;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ResourcesActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ResourceAdapter adapter;
    private EditText editTextSearch;
    private ArrayList<Resource> resourceList;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resources);

        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        ListView resourceListView = findViewById(R.id.resourceListView);
        resourceList = getResourceData();
        adapter = new ResourceAdapter(this, resourceList);
        resourceListView.setAdapter(adapter);

        editTextSearch = findViewById(R.id.editTextSearch);

        // Después de la inicialización de editTextSearch
        Button btnSort = findViewById(R.id.btnSort);
        btnSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Ordenar alfabéticamente de A-Z
                Collections.sort(resourceList, new Comparator<Resource>() {
                    @Override
                    public int compare(Resource resource1, Resource resource2) {
                        return resource1.getName().compareToIgnoreCase(resource2.getName());
                    }
                });

                // Actualizar la lista después de ordenar
                adapter.notifyDataSetChanged();
            }
        });

        Button btnSortZ = findViewById(R.id.btnSortZ);
        btnSortZ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Ordenar alfabéticamente de Z-A
                Collections.sort(resourceList, new Comparator<Resource>() {
                    @Override
                    public int compare(Resource resource1, Resource resource2) {
                        return resource2.getName().compareToIgnoreCase(resource1.getName());
                    }
                });

                // Actualizar la lista después de ordenar
                adapter.notifyDataSetChanged();
            }
        });

        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int before, int count) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                ArrayList<Resource> filteredList = filterResources(charSequence.toString());
                adapter.clear();
                adapter.addAll(filteredList);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        });

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_resources);

        resourceListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Resource selectedResource = resourceList.get(position); // Get from the sorted list
                String url = selectedResource.getResourceUrl();

                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private ArrayList<Resource> getResourceData() {

        ArrayList<Resource> resources = new ArrayList<>();

        resources.add(new Resource("JSTOR", "Biblioteca digital de revistas académicas, libros y fuentes primarias.", "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6d/JSTOR_icon_for_userbox.svg/640px-JSTOR_icon_for_userbox.svg.png", "https://www.jstor.org"));
        resources.add(new Resource("ResearchGate", "Red social para investigadores y científicos para compartir y descubrir investigación.", "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/ResearchGate_icon_SVG.svg/640px-ResearchGate_icon_SVG.svg.png", "https://www.researchgate.net"));
        resources.add(new Resource("arXiv", "Archivo de preimpresiones de artículos científicos en diversas disciplinas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/ArXiv_logo_2022.svg/640px-ArXiv_logo_2022.svg.png", "https://arxiv.org"));
        resources.add(new Resource("IEEE Xplore", "Explora artículos, conferencias y estándares en ingeniería y tecnología.", "https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/IEEE_logo.svg/640px-IEEE_logo.svg.png", "https://ieeexplore.ieee.org"));
        resources.add(new Resource("Nature", "Revista científica multidisciplinaria con artículos de investigación.", "https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/Nature_journal_logo.svg/640px-Nature_journal_logo.svg.png", "https://www.nature.com"));
        resources.add(new Resource("ScienceDirect", "Biblioteca en línea de artículos científicos, técnicos y médicos.", "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/ScienceDirect_logo.svg/640px-ScienceDirect_logo.svg.png", "https://www.sciencedirect.com"));
        resources.add(new Resource("SpringerLink", "Acceso a libros y revistas en ciencias, tecnología y medicina.", "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/CEE_Spring_Logo_transparent.svg/640px-CEE_Spring_Logo_transparent.svg.png", "https://link.springer.com"));
        resources.add(new Resource("EdX", "Plataforma de cursos en línea fundada por Harvard y el MIT.", "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/EdX_newer_logo.svg/640px-EdX_newer_logo.svg.png", "https://www.edx.org"));
        resources.add(new Resource("Research.com", "Acceso a millones de artículos científicos y recursos de investigación.", "https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Digital_Research_logo_1990.svg/640px-Digital_Research_logo_1990.svg.png", "https://www.research.com"));
        resources.add(new Resource("Cambridge Core", "Acceso a libros y revistas académicas de la Universidad de Cambridge.", "https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/Cambridge_Press_Cover_Emblem.jpg/640px-Cambridge_Press_Cover_Emblem.jpg", "https://www.cambridge.org/core"));
        resources.add(new Resource("The New York Times - Education", "Sección educativa del periódico con artículos y recursos para estudiantes.", "https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/New_York_Times_logo_variation.jpg/640px-New_York_Times_logo_variation.jpg", "https://www.nytimes.com/section/education"));
        resources.add(new Resource("MIT OpenCourseWare", "Cursos en línea gratuitos del Instituto Tecnológico de Massachusetts.", "https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Massachusetts_Institute_of_Technology_logo.svg/640px-Massachusetts_Institute_of_Technology_logo.svg.png", "https://ocw.mit.edu"));
        resources.add(new Resource("CERN Document Server", "Repositorio de documentos relacionados con la física de partículas y la investigación en CERN.", "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7d/CERN_logo.png/640px-CERN_logo.png", "https://cds.cern.ch"));
        resources.add(new Resource("SAGE Journals", "Acceso a revistas académicas en ciencias sociales, humanidades y más.", "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a4/Sage_logo_bright_green.jpg/640px-Sage_logo_bright_green.jpg", "https://journals.sagepub.com"));
        resources.add(new Resource("Taylor & Francis Online", "Acceso a revistas académicas y libros en diversas disciplinas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/9/90/Taylor_and_Francis_logo%2C_%28The_Ibis%2C_1900%29.jpg/640px-Taylor_and_Francis_logo%2C_%28The_Ibis%2C_1900%29.jpg", "https://www.taylorandfrancis.com"));
        resources.add(new Resource("PubMed", "Base de datos de artículos médicos y de ciencias de la salud.", "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/US-NLM-PubMed-Logo.svg/640px-US-NLM-PubMed-Logo.svg.png", "https://pubmed.ncbi.nlm.nih.gov"));
        resources.add(new Resource("ProQuest", "Biblioteca en línea con tesis, dissertaciones y contenido académico.", "https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Web_Quest.png/640px-Web_Quest.png", "https://www.proquest.com"));
        resources.add(new Resource("Wolfram Alpha", "Motor computacional que responde preguntas y genera visualizaciones.", "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Wolfram_Alpha_2022.svg/640px-Wolfram_Alpha_2022.svg.png", "https://www.wolframalpha.com"));
        resources.add(new Resource("Wikipedia", "Enciclopedia en línea colaborativa con información en varios idiomas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Wikipedia-logo-v2.svg/103px-Wikipedia-logo-v2.svg.png", "https://www.wikipedia.org"));
        resources.add(new Resource("NASA", "Explora el espacio y aprende sobre la agencia espacial estadounidense.", "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/180px-NASA_logo.svg.png", "https://www.nasa.gov"));
        resources.add(new Resource("Reddit", "Foros y comunidades para discutir una amplia variedad de temas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Reddit_wordmark.svg/640px-Reddit_wordmark.svg.png", "https://www.reddit.com"));
        resources.add(new Resource("Stack Overflow", "Comunidad de programadores para obtener y compartir conocimientos.", "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Stack_Overflow_icon.svg/640px-Stack_Overflow_icon.svg.png", "https://stackoverflow.com"));
        resources.add(new Resource("Amazon Kindle", "Plataforma para leer libros electrónicos en varios dispositivos.", "https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Amazon_Kindle_logo.svg/640px-Amazon_Kindle_logo.svg.png", "https://www.amazon.com/kindle"));
        resources.add(new Resource("Kaggle", "Plataforma para la ciencia de datos, aprendizaje automático y análisis.", "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7c/Kaggle_logo.png/640px-Kaggle_logo.png", "https://www.kaggle.com"));
        resources.add(new Resource("National Geographic", "Explora el mundo a través de fotografías y artículos fascinantes.", "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/National-Geographic-Logo.svg/640px-National-Geographic-Logo.svg.png", "https://www.nationalgeographic.com"));
        resources.add(new Resource("Trello", "Herramienta de gestión de proyectos con tableros y listas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/Antu_trello.svg/640px-Antu_trello.svg.png", "https://trello.com"));
        resources.add(new Resource("OpenWeatherMap", "Consulta el pronóstico del tiempo en todo el mundo.", "https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/OpenWeatherMap_logo.png/640px-OpenWeatherMap_logo.png", "https://openweathermap.org"));
        resources.add(new Resource("Medium", "Plataforma de blogging con artículos sobre diversos temas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Medium_logo_Monogram.svg/640px-Medium_logo_Monogram.svg.png", "https://medium.com"));
        resources.add(new Resource("Khan Academy", "Plataforma educativa en línea con cursos gratuitos de matemáticas, ciencias y más.", "https://upload.wikimedia.org/wikipedia/commons/thumb/1/15/Khan_Academy_Logo_Old_version_2015.jpg/640px-Khan_Academy_Logo_Old_version_2015.jpg", "https://www.khanacademy.org"));
        resources.add(new Resource("Duolingo", "Aprende idiomas de forma gratuita con juegos y actividades interactivas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Duolingo_logo_%282019%29.svg/640px-Duolingo_logo_%282019%29.svg.png", "https://www.duolingo.com"));
        resources.add(new Resource("Coursera", "Acceso a cursos en línea de universidades y organizaciones de todo el mundo.", "https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Coursera-logo-square.png/640px-Coursera-logo-square.png", "https://www.coursera.org"));
        resources.add(new Resource("TED Talks", "Charlas inspiradoras sobre una amplia variedad de temas por expertos en la materia.", "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ed/TED_stage_logo_from_Flickr_%28cropped%29.jpg/640px-TED_stage_logo_from_Flickr_%28cropped%29.jpg", "https://www.ted.com"));
        resources.add(new Resource("Codecademy", "Aprende a programar interactuando con proyectos y desafíos en línea.", "https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Code-Academy-Logo_png.png/640px-Code-Academy-Logo_png.png", "https://www.codecademy.com"));
        resources.add(new Resource("ChatGPT", "Fundamental para todo estudiante. Utiliza esta potente herramienta para resolver tus dudas, realizar redacciones, etc...", "https://ih0.redbubble.net/image.5070246022.3065/raf,360x360,075,t,fafafa:ca443f4786.jpg", "https://chat.openai.com"));
        resources.add(new Resource("Proyecto Gutenberg", "Una gran librería online, con muchísimo material de calidad en distintos idiomas, totalmente gratuito.", "https://banner2.cleanpng.com/20180611/rcy/kisspng-project-gutenberg-e-book-epub-library-project-gutenberg-5b1e009d68b8f9.948028121528692893429.jpg", "https://www.gutenberg.org"));
        resources.add(new Resource("Google Scholar", "El buscador de Google de siempre pero con un motor de búsqueda especializado en contenido académico y científico.", "https://res.cloudinary.com/startup-grind/image/upload/c_fill,dpr_2.0,f_auto,g_center,h_1080,q_100,w_1080/v1/gcs/platform-data-goog/events/googleScholar-02_pAlkc7s.jpg", "https://scholar.google.es"));
        resources.add(new Resource("Google Collab", "Disfruta de un Jupyter notebook online, sin carga en tu PC.", "https://logowik.com/content/uploads/images/google-colaboratory6512.jpg", "https://colab.google"));
        resources.add(new Resource("YouTube", "Plataforma de videos para compartir y descubrir contenido.", "https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/YouTube_full-color_icon_%282017%29.svg/640px-YouTube_full-color_icon_%282017%29.svg.png", "https://www.youtube.com"));
        resources.add(new Resource("LinkedIn", "Red profesional para conectar con colegas y buscar empleo.", "https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/LinkedIn_logo_In-Black.svg/640px-LinkedIn_logo_In-Black.svg.png", "https://www.linkedin.com"));
        resources.add(new Resource("Twitter", "Red social para compartir pensamientos y noticias en tiempo real.", "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2d/Twitter_X.png/640px-Twitter_X.png", "https://twitter.com"));
        resources.add(new Resource("Instagram", "Plataforma de redes sociales para compartir fotos y videos.", "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Instagram_logo_2016.svg/640px-Instagram_logo_2016.svg.png", "https://www.instagram.com"));
        resources.add(new Resource("GitHub", "Plataforma de desarrollo colaborativo para programadores.", "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c2/GitHub_Invertocat_Logo.svg/640px-GitHub_Invertocat_Logo.svg.png", "https://github.com"));
        resources.add(new Resource("Netflix", "Servicio de transmisión en línea para ver películas y programas de televisión.", "https://upload.wikimedia.org/wikipedia/commons/thumb/7/75/Netflix_icon.svg/640px-Netflix_icon.svg.png", "https://www.netflix.com"));
        resources.add(new Resource("Spotify", "Plataforma de transmisión de música con millones de canciones.", "https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Spotify_logo_without_text.svg/640px-Spotify_logo_without_text.svg.png", "https://www.spotify.com"));
        resources.add(new Resource("Pinterest", "Red social para descubrir y guardar ideas creativas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Pinterest-logo.png/640px-Pinterest-logo.png", "https://www.pinterest.com"));
        resources.add(new Resource("WhatsApp", "Aplicación de mensajería instantánea para chats individuales y grupales.", "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/WhatsApp.svg/200px-WhatsApp.svg.png", "https://www.whatsapp.com"));
        resources.add(new Resource("Adobe Creative Cloud", "Suite de aplicaciones creativas para diseño, fotografía y video.", "https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Adobe_Creative_Cloud_mark.svg/640px-Adobe_Creative_Cloud_mark.svg.png", "https://www.adobe.com/creativecloud.html"));
        resources.add(new Resource("Evernote", "Herramienta de organización para notas, listas y recordatorios.", "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Evernote_ETC_%287872360822%29.jpg/640px-Evernote_ETC_%287872360822%29.jpg", "https://evernote.com"));
        resources.add(new Resource("Google Drive", "Servicio de almacenamiento en la nube para documentos y archivos.", "https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Google_Drive_icon_%282020%29.svg/640px-Google_Drive_icon_%282020%29.svg.png", "https://drive.google.com"));
        resources.add(new Resource("Microsoft Office 365", "Suite de aplicaciones de productividad, como Word y Excel.", "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4f/Microsoft_Office_2013-2019_logo_and_wordmark.svg/640px-Microsoft_Office_2013-2019_logo_and_wordmark.svg.png", "https://www.microsoft.com/microsoft-365"));
        resources.add(new Resource("Zoom", "Plataforma de videoconferencia para reuniones virtuales.", "https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Zoom_I.svg/640px-Zoom_I.svg.png", "https://zoom.us"));
        resources.add(new Resource("Slack", "Herramienta de mensajería para equipos y colaboración en proyectos.", "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Slack_Logo_Pre_2019.svg/640px-Slack_Logo_Pre_2019.svg.png", "https://slack.com"));
        resources.add(new Resource("Google Maps", "Servicio de mapas para navegación y exploración de ubicaciones.", "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bd/Google_Maps_Logo_2020.svg/640px-Google_Maps_Logo_2020.svg.png", "https://www.google.com/maps"));
        resources.add(new Resource("Snapchat", "Red social para compartir fotos y videos que desaparecen después de verse.", "https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/Logo_de_Snapchat_2011.png/640px-Logo_de_Snapchat_2011.png", "https://www.snapchat.com"));
        resources.add(new Resource("Microsoft Teams", "Plataforma de colaboración para comunicación y trabajo en equipo.", "https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Microsoft_Office_Teams_%282018%E2%80%93present%29.svg/640px-Microsoft_Office_Teams_%282018%E2%80%93present%29.svg.png", "https://www.microsoft.com/microsoft-teams"));
        resources.add(new Resource("Discord", "Plataforma de comunicación para jugadores y comunidades en línea.", "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/Discord_Color_Text_Logo_No_Padding.svg/640px-Discord_Color_Text_Logo_No_Padding.svg.png", "https://discord.com"));
        resources.add(new Resource("SoundCloud", "Plataforma de transmisión de música para descubrir y compartir pistas.", "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Antu_soundcloud.svg/640px-Antu_soundcloud.svg.png", "https://soundcloud.com"));

        return resources;
    }

    private ArrayList<Resource> filterResources(String query) {
        query = query.toLowerCase();
        ArrayList<Resource> filteredList = new ArrayList<>();

        for (Resource resource : getResourceData()) {
            if (resource.getName().toLowerCase().contains(query) || resource.getDescription().toLowerCase().contains(query)) {
                filteredList.add(resource);
            }
        }

        return filteredList;
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return Utilidades.onNavigationItemSelected(this, item);
    }
}

