package com.esei.dm.unileaks.BasesDeDatos;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class ForumDatabaseHelper extends SQLiteOpenHelper {

    private SharedPreferences sharedPreferences;
    private static final String DATABASE_NAME = "ForumDB";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_TOPICS = "topics";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_CONTENT = "content";
    private static final String COLUMN_AUTHOR = "author";

    private static final String TABLE_REPLIES = "replies";
    private static final String COLUMN_REPLY_ID = "id";
    private static final String COLUMN_TOPIC_ID = "topic_id";
    private static final String COLUMN_REPLY_CONTENT = "content";
    private static final String COLUMN_REPLY_AUTHOR = "author";

    public ForumDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        sharedPreferences = context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crear tabla de temas
        String CREATE_TOPICS_TABLE = "CREATE TABLE " + TABLE_TOPICS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_TITLE + " TEXT,"
                + COLUMN_CONTENT + " TEXT,"
                + COLUMN_AUTHOR + " TEXT" + ")";
        db.execSQL(CREATE_TOPICS_TABLE);

        // Crear tabla de respuestas
        String CREATE_REPLIES_TABLE = "CREATE TABLE " + TABLE_REPLIES + "("
                + COLUMN_REPLY_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_TOPIC_ID + " INTEGER,"
                + COLUMN_REPLY_CONTENT + " TEXT,"
                + COLUMN_REPLY_AUTHOR + " TEXT" + ")";
        db.execSQL(CREATE_REPLIES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Borrar tablas antiguas si existen
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TOPICS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REPLIES);

        // Crear tablas de nuevo
        onCreate(db);
    }

    public Cursor getTopicById(long topicId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] selectionArgs = {String.valueOf(topicId)};
        String selection = COLUMN_ID + " = ?";
        return db.query(TABLE_TOPICS, null, selection, selectionArgs, null, null, null);
    }
    public long addTopic(String title, String content) {
        SQLiteDatabase db = this.getWritableDatabase();
        String username = sharedPreferences.getString("username", "");
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_CONTENT, content);
        values.put(COLUMN_AUTHOR, username); // Guardar el autor del tema

        long topicId = db.insert(TABLE_TOPICS, null, values);

        db.close();

        //Log.d("ForumDatabaseHelper", "Topic added with ID: " + topicId);

        return topicId;
    }

    public void addReply(long topicId, String replyContent, String author) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_TOPIC_ID, topicId);
        values.put(COLUMN_REPLY_CONTENT, replyContent);
        values.put(COLUMN_REPLY_AUTHOR, author); // Guardar el autor de la respuesta

        db.insert(TABLE_REPLIES, null, values);

        db.close();

        //Log.d("ForumDatabaseHelper", "Reply added to topic ID " + topicId);
    }

    public Cursor getAllTopics() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_TOPICS, null, null, null, null, null, null);
    }

    public Cursor getRepliesForTopic(long topicId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] selectionArgs = {String.valueOf(topicId)};
        return db.query(TABLE_REPLIES, null, COLUMN_TOPIC_ID + " = ?", selectionArgs, null, null, null);
    }
}
