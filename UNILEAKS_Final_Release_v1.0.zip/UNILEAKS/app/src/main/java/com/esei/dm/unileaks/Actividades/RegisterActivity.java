package com.esei.dm.unileaks.Actividades;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.esei.dm.unileaks.BasesDeDatos.DatabaseHelper;
import com.esei.dm.unileaks.R;

public class RegisterActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button registerButton;
    private Button backToLoginButton;
    private DatabaseHelper databaseHelper;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Obtener las preferencias compartidas
        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);

        // Configurar el tema antes de setContentView
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Inicializar elementos de la interfaz de usuario
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        registerButton = findViewById(R.id.registerButton);
        backToLoginButton = findViewById(R.id.backToLoginButton);
        databaseHelper = new DatabaseHelper(this);

        // Configurar el listener para el botón de registro
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty()) {
                    showToast("No puedes dejar campos vacíos.");
                } else if (username.length() < 5 || password.length() < 5) {
                    showToast("El nombre de usuario y la contraseña deben ser de al menos 5 caracteres.");
                } else if (databaseHelper.checkUsername(username)) {
                    showToast("El nombre de usuario ya existe.");
                } else {
                    // Agregar el usuario a la base de datos
                    databaseHelper.addUser(username, password);
                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                    showToast("Te has registrado correctamente.");
                }
            }
        });

        // Configurar el listener para el botón "Back to Login"
        backToLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Volver a la actividad principal de inicio de sesión
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Configurar el tema según las preferencias
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    // Método para mostrar un mensaje Toast
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
