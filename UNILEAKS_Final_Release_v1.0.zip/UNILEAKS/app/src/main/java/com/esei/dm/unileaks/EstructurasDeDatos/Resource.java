package com.esei.dm.unileaks.EstructurasDeDatos;

public class Resource {
    private String name;
    private String description;
    private String imageUrl;
    private String resourceUrl;

    public Resource(String name, String description, String imageUrl, String resourceUrl) {
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
        this.resourceUrl = resourceUrl;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getResourceUrl() {
        return resourceUrl;
    }
}
