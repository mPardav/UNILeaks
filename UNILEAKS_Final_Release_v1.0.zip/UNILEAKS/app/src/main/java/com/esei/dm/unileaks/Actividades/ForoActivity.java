package com.esei.dm.unileaks.Actividades;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.esei.dm.unileaks.BasesDeDatos.ForumDatabaseHelper;
import com.esei.dm.unileaks.R;
import com.esei.dm.unileaks.IU.Utilidades;
import com.esei.dm.unileaks.IU.WebAppInterface;
import com.google.android.material.navigation.NavigationView;

public class ForoActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private WebView webView;
    private ForumDatabaseHelper databaseHelper;
    private SharedPreferences sharedPreferences;
    private DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);

        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foro);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_forum);

        databaseHelper = new ForumDatabaseHelper(this);

        webView = findViewById(R.id.webViewForo);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);

        // Agregar la interfaz entre JavaScript y Java
        webView.addJavascriptInterface(new WebAppInterface(this, databaseHelper), "Android");
        webView.setWebChromeClient(new WebChromeClient());

        // Concatena el nombre de usuario a la URL eligiendo modo claro u oscuro importando desde las preferencias
        String url;
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            url = "file:///android_asset/Foro/ForoDark.html";
        } else {
            url = "file:///android_asset/Foro/Foro.html";
        }
        webView.loadUrl(url);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return Utilidades.onNavigationItemSelected(this, item);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}
