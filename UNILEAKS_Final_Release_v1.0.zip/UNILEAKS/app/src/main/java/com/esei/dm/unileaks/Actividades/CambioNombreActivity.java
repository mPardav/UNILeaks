package com.esei.dm.unileaks.Actividades;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.esei.dm.unileaks.BasesDeDatos.DatabaseHelper;
import com.esei.dm.unileaks.IU.Utilidades;
import com.esei.dm.unileaks.R;

public class CambioNombreActivity extends AppCompatActivity {

    private EditText nuevoNombre;
    private DatabaseHelper databaseHelper;
    private EditText confirmarNuevoNombre;
    private Button confirmar;
    private Button cancelar;

    private SharedPreferences sharedPreferences;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sharedPreferences = getSharedPreferences("AppPreferences", MODE_PRIVATE);

        // Configuración del modo oscuro según las preferencias del usuario
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cambio_nombre);
        databaseHelper = new DatabaseHelper(this);

        // Inicialización de elementos de la interfaz de usuario
        nuevoNombre = findViewById(R.id.nuevoNombreEditText);
        confirmarNuevoNombre = findViewById(R.id.confirmarNuevoNombreEditText);
        confirmar = findViewById(R.id.confirmarButton);
        cancelar = findViewById(R.id.cancelarButton);

        // Configuración del listener para el botón de confirmar
        confirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nuevoNombreUsuario = nuevoNombre.getText().toString();
                String confirmarNombre = confirmarNuevoNombre.getText().toString();

                String savedUsername = sharedPreferences.getString("username", "");
                int savedUserId = sharedPreferences.getInt("userId", -1);

                // Verificación de la información y acciones correspondientes
                if (!savedUsername.isEmpty() && savedUserId != -1) {
                    if (!nuevoNombreUsuario.equals(confirmarNombre)) {
                        showToast("Los nombres no coinciden.");
                    } else if(nuevoNombreUsuario.length()<5){
                        showToast("Tu nuevo nombre de usuario debe ser de al menos 5 caracteres.");
                    }else {
                        if (databaseHelper.checkUsername(nuevoNombreUsuario)) {
                            showToast("El nombre escogido ya pertenece a otro usuario.");
                        } else {
                            AlertDialog.Builder builder = new AlertDialog.Builder(CambioNombreActivity.this);
                            builder.setTitle("Confirmar cambio de nombre.");
                            builder.setMessage("¿Estás seguro de que quieres cambiar tu nombre de usuario?");

                            builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    // Acción al hacer clic en "Sí"
                                    databaseHelper.changeUsername(savedUserId, nuevoNombreUsuario);
                                    @SuppressLint("CommitPrefEdits") SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("username", nuevoNombreUsuario);
                                    editor.apply();
                                    Intent intent = new Intent(CambioNombreActivity.this, ProfileActivity.class);
                                    startActivity(intent);
                                }
                            });

                            builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    // Acción al hacer clic en "Cancelar" o se cancela el diálogo
                                }
                            });

                            AlertDialog dialog = builder.create();
                            dialog.show();
                        }
                    }
                } else {
                    showToast("Error");
                }
            }
        });

        // Configuración del listener para el botón de cancelar
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CambioNombreActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Actualización del modo oscuro al reanudar la actividad
        if (sharedPreferences.getBoolean("DarkMode", false)) {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            getDelegate().setLocalNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    // Método para mostrar un Toast con el mensaje proporcionado
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
